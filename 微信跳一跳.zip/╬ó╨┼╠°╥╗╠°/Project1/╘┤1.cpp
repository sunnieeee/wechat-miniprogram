//#include<opencv2\opencv.hpp>
//#include<iostream>
//using namespace cv;
//using namespace std;
//int main()
//{
//	Mat src;
//	src = imread("5.png");
//	imshow("0", src);
//	waitKey();
//	/*for (int j = 0; j<src.rows; j++)
//		for (int i = 0; i<src.cols; i++)
//		{
//			cout << src.at<Vec3b>(j, i)[0] << endl;//green
//			cout << src.at<Vec3b>(j, i)[1] << endl;//blue
//			cout << src.at<Vec3b>(j, i)[2] << endl;//red
//
//		}
//	*/return 0;
//}